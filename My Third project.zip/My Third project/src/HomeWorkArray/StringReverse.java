package HomeWorkArray;

public class StringReverse {
    // using for loop
    public static void main(String[] args) {
        String name = " trupti";
           String rev="";
        int leng = name.length();

        for ( int i=leng-1; i>=0;i-- ){

          rev= rev +name.charAt(i) ;
        }
        System.out.println(" Reverse of "+name+" is "+rev);

       String str =" My Nmae is Trupti";
          String a[]=str.split("");
             for ( int i=0; i<a.length;i++)
        {
        System.out.println("");
        }
         for (int i=a.length-1; i>=0;i--)
         {
           System.out.println(a[i]+"");
         }


    }

}

package HomeWorkArray;
import java.util.Scanner;
public class ArrayFix2 {
// 2. Write a Java program to sum values of an array.
    public static void main(String[] args) {

        //int arr[] = {3, 5, 7};

     // for ( int i : arr) // using for each loop

     // System.out.println( i);

    Scanner s1=new Scanner(System.in);

    int number[]= new int [5];
      int sum=0;

        System.out.println(" enter the element in array ");

        for (int i=0; i<5;i++) {

      number[i]= s1.nextInt();

      sum= sum+ number[i];

    }
      System.out.println(  );



    }
}

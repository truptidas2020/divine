package HomeWorkArray;

public class ArrayEx1 {
//1. Write a Java program to sort a numeric array and a string array.

    public static void main(String[] args) {

        int alist[]=new int [7];

        alist[0]=3;
        alist[1]=5;
        alist[2]=6;
        alist[3]=7;
        alist[4]=8;
        alist[5]=9;
        alist[6]=10;


        for( int a=0; a< alist.length;a++)
         //for( int a:alist) {
             System.out.println(alist[a]);
         }




    }







package HomeWorkArray;

public class StringReverse2 {
    public static void main(String[] args) {
        String str =" My Nmae is Trupti";

        String str1="";

        String a[]=str.split("");

        for ( int i=0; i<a.length;i++)
        {
            System.out.println(a[i]+"");
        }
        for (int i=a.length-1; i>=0;i--)
        {
            str1=str1+a[i]+"";
        }
        //System.out.printf();

    }

}


